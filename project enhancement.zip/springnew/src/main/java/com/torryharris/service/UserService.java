package com.torryharris.service;


import com.torryharris.model.UserRegDTO;

public interface UserService {
	
	public boolean registerUser(UserRegDTO user);
}
